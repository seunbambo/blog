<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center">
        <h1>Digital Health</h1>
        <p>You are as wealthy as your health</p>
        <?php if(Auth::guest()): ?>
            <a class="btn btn-primary btn-lg" href="/login" role="button">Login</a> <a class="btn btn-success btn-lg" href="/register" role="button">Staff Register</a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>