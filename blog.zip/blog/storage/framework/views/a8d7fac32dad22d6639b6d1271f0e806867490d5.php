<?php $__env->startSection('content'); ?>
    <h1>Add Patient</h1>
    <?php echo Form::open(['action' => 'PatientsController@store', 'method' => 'POST']); ?>

        <div class="form-group">
            <?php echo e(Form::label('name', 'Name')); ?>

            <?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'Full Name'])); ?>

        </div>
        <div class="form-group">
                <?php echo e(Form::label('phone', 'Phone')); ?>

                <?php echo e(Form::text('phone', '', ['class' => 'form-control', 'placeholder' => 'Telephone'])); ?>

        </div>
        <div class="form-group">
                <?php echo e(Form::label('email', 'Email')); ?>

                <?php echo e(Form::text('email', '', ['class' => 'form-control', 'placeholder' => 'Email Address'])); ?>

        </div>
        <div class="form-group">
                <?php echo e(Form::label('home_address', 'Home Address')); ?>

                <?php echo e(Form::text('home_address', '', ['class' => 'form-control', 'placeholder' => 'Home Address'])); ?>

        </div>
        <div class="form-group">
                <?php echo e(Form::label('health_issue', 'Health Issue')); ?>

                <?php echo e(Form::text('health_issue', '', ['class' => 'form-control', 'placeholder' => 'Health Issue'])); ?>

        </div>
        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>