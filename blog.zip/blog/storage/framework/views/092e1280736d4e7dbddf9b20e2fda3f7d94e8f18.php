<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading"><center><h3>Patients Weekly Visit</h3></center></div>

                <div class="panel-body">
                    <?php echo $chart->html(); ?>

                </div><br>

                <div class="card mb-3">
                    <div class="card-header">
                        <i class="fa fa-area-chart"></i>Trend</div>
                    <div class="card-body">
                        <canvas id="myAreaChart" width="100%" height="30"></canvas>
                    </div>
                    <div class="card-footer small text-muted">Updated at <?php echo date('F j. Y', time()) ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo Charts::scripts(); ?>

<?php echo $chart->script(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection( 'scripts' ); ?>
    <script src="<?php echo e(url( 'vendor/jquery.min.js' )); ?>"></script>

    <script src="<?php echo e(url( 'vendor/Chart.min.js' )); ?>"></script>

    <script src="<?php echo e(url( 'vendor/create-charts.js' )); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>