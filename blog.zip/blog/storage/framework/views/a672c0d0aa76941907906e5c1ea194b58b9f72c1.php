<?php $__env->startSection('content'); ?>
    <h1>Patients</h1>
    <?php if(count($patients) > 0): ?>
        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="well">
            <h3><a href="/patients/<?php echo e($patient->id); ?>"><?php echo e($patient->name); ?></a></h3>
            <small>Created on <?php echo e($patient->created_at); ?> by <?php echo e($patient->user->name); ?></small>
            </div>
            <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($patients->links()); ?>

    <?php else: ?>
        <p>No patient found</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>