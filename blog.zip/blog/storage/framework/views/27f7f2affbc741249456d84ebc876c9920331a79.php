<?php $__env->startSection('content'); ?>
    <a href="/patients" class="btn btn-default">Go Back</a>
    <h1><?php echo e($patient->name); ?></h1>
    <div>
        <b>Address: </b><?php echo e($patient->home_address); ?> <br>
        <b>Email: </b><?php echo e($patient->email); ?> <br>
        <b>Telephone: </b><?php echo e($patient->phone); ?> <br>
        <b>Health Issue: </b><?php echo e($patient->health_issue); ?> <br>
    </div>
    <hr>
    <small>Created on <?php echo e($patient->created_at); ?> by <?php echo e($patient->user->name); ?></small>
    <hr>
    <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->id == $patient->user_id): ?>
            <a href="/patients/<?php echo e($patient->id); ?>/edit" class="btn btn-default">Edit</a>
            <?php echo Form::open(['action' => ['PatientsController@destroy', $patient->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>

        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>